import java.util.Random;

public class LinkedListDS{
    //
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)

//


        private LinkedListDS.Node<Integer> head = null;
        private LinkedListDS.Node<Integer> tail = null;
        private int size = 0;

        LinkedListDS() {
        }

        public int size() {
            return this.size;
        }

        public boolean isEmpty() {
            return this.size == 0;
        }

        public Integer first() {
            return this.isEmpty() ? null : this.head.getElement();
        }

        public Integer last() {
            return this.isEmpty() ? null : this.tail.getElement();
        }

    /**
     * A method addFirst to add elements into an array at the first location. the method
     * will take all the preceding elements and shift them back one, adding an element at the
     * first space in the array, and returning the element.
     */

        public void addFirst(Integer e) {
            this.head = new LinkedListDS.Node(e, this.head);
            if (this.size == 0) {
                this.tail = this.head;
            }

            ++this.size;
        }


    /**
     * similar to add first, addLast will add an element to the end of the list
     * and will make the array one space larger for said element.
     * @return
     */

    public void addLast(Integer e) {
            LinkedListDS.Node<Integer> newest = new LinkedListDS.Node(e, (LinkedListDS.Node)null);
            if (this.isEmpty()) {
                this.head = newest;
            } else {

                this.tail.setNext(newest);
            }

            this.tail = newest;
            ++this.size;
        }

        public Integer removeFirst() {
            if (this.isEmpty()) {
                return null;
            } else {
                Integer answer = this.head.getElement();
                this.head = this.head.getNext();
                --this.size;
                if (this.size == 0) {
                    this.tail = null;
                }

                return answer;
            }
        }

    /**
     * toString returns the elements in the array to a string method for printable statements
     * @return
     */
        public String toString() {
            StringBuilder sb = new StringBuilder("(");

            for(LinkedListDS.Node walk = this.head; walk != null; walk = walk.getNext()) {
                sb.append(walk.getElement());
                if (walk != this.tail) {
                    sb.append(", ");
                }
            }

            sb.append(")");
            return sb.toString();
        }

    /**
     * getNth is a method created to pass in a number, and the method
     * will take the number passed, go to that element and return the value
     * in that location.
     * @param index
     * @return
     */

        public Integer getNth(int index) {
            LinkedListDS.Node<Integer> location = this.head;


            int count;
            for (count = 0; location != null; location = location.next) {
                if (count == index) {
                    return location.element;
                }

                count++;
                count = index;

            }

            return getNth(index);
        }

        public void addAfter(int n, Integer data) {
            LinkedListDS.Node<Integer> walk = this.head;
            LinkedListDS.Node<Integer> newNode = new LinkedListDS.Node(data, (LinkedListDS.Node)null);

            for(int i = 0; i < n; ++i) {
                walk = walk.getNext();
            }

            newNode.setNext(walk.getNext());
            walk.setNext(newNode);
            if (n == 0) {
                this.head = walk;
            }

            if (n == this.size - 1) {
                this.tail = newNode;
            }

            ++this.size;
        }

        private static class Node<Integer> {
            private Integer element;
            private LinkedListDS.Node<Integer> next;

            public Node(Integer e, LinkedListDS.Node<Integer> n) {
                this.element = e;
                this.next = n;
            }

            public Integer getElement() {
                return this.element;
            }

            public LinkedListDS.Node<Integer> getNext() {
                return this.next;
            }

            public void setNext(LinkedListDS.Node<Integer> n) {
                this.next = n;
            }
        }
    /** randomFill builds random array and fills with random numbers specified to a given length
     */

        public void randomFill(int size) {
            Random rand = new Random();

            for (int i = 0; i < size; ++i) {
                int temp = rand.nextInt();
                Integer temp2 = new Integer(temp);
                addFirst(temp2);

        }
    }
    }


